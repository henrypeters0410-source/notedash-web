# NoteDash (Web PWA)
A fast, offline-capable notes web app built with vanilla JS + IndexedDB. Installable on iOS/Android/Desktop as a PWA.

## Features
- Create/Edit/Delete notes
- Pin & Archive
- Search
- Offline-ready (Service Worker)
- Local storage in IndexedDB (no server required)
- Web Share / Clipboard fallback
- Responsive layout

## Quick Start (Local)
1. Unzip.
2. Serve via a local web server (PWA needs https or localhost):
   - Python: `python3 -m http.server 5173`
   - Node: `npx http-server -p 5173`
3. Open http://localhost:5173

## Deploy
- **Netlify**: Drag & drop the folder in the dashboard. (Build: none, Publish dir: root)
- **Vercel**: Import as static project, framework = "Other".
- **GitHub Pages**: Push to a repo → Settings → Pages → Source: `main` (root).

## iOS Install
1. Open your site in Safari on iPhone/iPad.
2. Share → Add to Home Screen.
3. Launch from Home Screen (full-screen app experience).

## Notes
- Data is local to the device/browser. To sync across devices, connect a backend (e.g., Supabase/Firebase) and replace db.js with API calls.
- To clear all data, clear site data in browser settings.
