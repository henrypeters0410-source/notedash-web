import { getAllNotes, putNote, deleteNote } from './db.js';

const $ = (s) => document.querySelector(s);
const notesList = $('#notesList');
const emptyState = $('#emptyState');
const searchInput = $('#searchInput');
const clearSearch = $('#clearSearch');
const filterSelect = $('#filterSelect');
const newBtn = $('#newBtn');

const editorDialog = $('#editorDialog');
const titleInput = $('#titleInput');
const bodyInput = $('#bodyInput');
const pinBtn = $('#pinBtn');
const archiveBtn = $('#archiveBtn');
const shareBtn = $('#shareBtn');
const deleteBtn = $('#deleteBtn');
const timestamp = $('#timestamp');

let notes = [];
let current = null;

async function load() {
  notes = await getAllNotes();
  render();
}

function render() {
  const q = (searchInput.value || '').toLowerCase();
  const showArchived = filterSelect.value === 'archived';
  let view = notes
    .filter(n => !!n)
    .filter(n => (n.isArchived === showArchived))
    .filter(n => !q || (n.title?.toLowerCase().includes(q) || n.body?.toLowerCase().includes(q)))
    .sort((a,b) => {
      if ((a.isPinned === b.isPinned)) return new Date(b.updatedAt) - new Date(a.updatedAt);
      return a.isPinned ? -1 : 1;
    });

  notesList.innerHTML = '';
  if (!view.length) {
    emptyState.classList.remove('hidden');
    return;
  }
  emptyState.classList.add('hidden');

  for (const n of view) {
    const li = document.createElement('li');
    li.className = 'note';
    li.innerHTML = `
      <div class="noteHeader">
        <div class="noteTitle">${escapeHTML(n.title || 'Untitled')}</div>
        <div class="noteActions">
          <button class="iconBtn" data-action="pin" data-id="${n.id}" title="${n.isPinned ? 'Unpin' : 'Pin'}">📌</button>
          <button class="iconBtn" data-action="archive" data-id="${n.id}" title="${n.isArchived ? 'Unarchive' : 'Archive'}">🗄️</button>
          <button class="iconBtn" data-action="delete" data-id="${n.id}" title="Delete">🗑️</button>
        </div>
      </div>
      <div class="noteBody">${escapeHTML((n.body || '').slice(0, 400))}</div>
      <div class="noteMeta">${formatDate(n.updatedAt)}</div>
    `;
    li.addEventListener('click', (e) => {
      if (e.target.closest('.iconBtn')) return;
      openEditor(n.id);
    });
    li.querySelector('[data-action="pin"]').addEventListener('click', async (e) => {
      e.stopPropagation();
      n.isPinned = !n.isPinned;
      n.updatedAt = new Date().toISOString();
      await putNote(n); await load();
    });
    li.querySelector('[data-action="archive"]').addEventListener('click', async (e) => {
      e.stopPropagation();
      n.isArchived = !n.isArchived;
      n.updatedAt = new Date().toISOString();
      await putNote(n); await load();
    });
    li.querySelector('[data-action="delete"]').addEventListener('click', async (e) => {
      e.stopPropagation();
      if (confirm('Delete this note?')) { await deleteNote(n.id); await load(); }
    });
    notesList.appendChild(li);
  }
}

function escapeHTML(str) {
  return (str || '').replace(/[&<>"']/g, (m) => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
  })[m]);
}

function formatDate(iso) {
  try { return new Date(iso).toLocaleString(); } catch { return ''; }
}

async function openEditor(id) {
  current = notes.find(n => n.id === id);
  if (!current) return;
  titleInput.value = current.title || '';
  bodyInput.value = current.body || '';
  timestamp.textContent = 'Updated ' + formatDate(current.updatedAt);
  editorDialog.showModal();
}

function newNote() {
  const n = {
    id: crypto.randomUUID(),
    title: '',
    body: '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isPinned: false,
    isArchived: false
  };
  notes.push(n);
  putNote(n).then(() => { render(); openEditor(n.id); });
}

searchInput.addEventListener('input', render);
clearSearch.addEventListener('click', () => { searchInput.value=''; render(); });
filterSelect.addEventListener('change', render);
newBtn.addEventListener('click', newNote);

titleInput.addEventListener('input', () => {
  if (!current) return;
  current.title = titleInput.value;
  current.updatedAt = new Date().toISOString();
});
bodyInput.addEventListener('input', () => {
  if (!current) return;
  current.body = bodyInput.value;
  current.updatedAt = new Date().toISOString();
});

pinBtn.addEventListener('click', async () => {
  if (!current) return;
  current.isPinned = !current.isPinned;
  current.updatedAt = new Date().toISOString();
  await putNote(current); await load();
});
archiveBtn.addEventListener('click', async () => {
  if (!current) return;
  current.isArchived = !current.isArchived;
  current.updatedAt = new Date().toISOString();
  await putNote(current); await load();
});

shareBtn.addEventListener('click', async () => {
  if (!current) return;
  const text = (current.title || 'Untitled') + '\n\n' + (current.body || '');
  if (navigator.share) {
    try { await navigator.share({ title: current.title || 'Note', text }); }
    catch(_) {}
  } else {
    await navigator.clipboard.writeText(text);
    alert('Copied to clipboard.');
  }
});

deleteBtn.addEventListener('click', async () => {
  if (!current) return;
  if (confirm('Delete this note?')) {
    await deleteNote(current.id);
    editorDialog.close();
    await load();
  }
});

// Persist edits on dialog close
$('#editorForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (current) { await putNote(current); }
  editorDialog.close();
  await load();
});

// Service worker registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(console.error);
  });
}

load();
